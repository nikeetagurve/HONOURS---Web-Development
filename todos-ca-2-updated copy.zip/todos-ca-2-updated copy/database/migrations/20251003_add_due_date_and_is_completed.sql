-- Ensure table exists and has required columns
CREATE TABLE IF NOT EXISTS todos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255) NOT NULL,
    due_date DATE NOT NULL,
    is_completed TINYINT(1) NOT NULL DEFAULT 0
);

-- If table already exists but missing columns, add them safely
ALTER TABLE todos ADD COLUMN IF NOT EXISTS due_date DATE NOT NULL DEFAULT (CURRENT_DATE);
ALTER TABLE todos ADD COLUMN IF NOT EXISTS is_completed TINYINT(1) NOT NULL DEFAULT 0;
