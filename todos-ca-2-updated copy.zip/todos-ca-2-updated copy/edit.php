<?php
require 'database/db.php';

$pdo = db_connect();

// Fetch existing todo
if (!isset($_GET['id']) && !isset($_POST['id'])) {
    http_response_code(400);
    echo "Missing id";
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : intval($_POST['id']);
$todo = null;
$errorMessage = null;
$successMessage = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $description = trim($_POST['description'] ?? '');
    $due_date = trim($_POST['due_date'] ?? '');
    if ($description === '' || $due_date === '') {
        $errorMessage = "All fields are required";
    } else {
        // Update
        $stmt = $pdo->prepare("UPDATE todos SET description = ?, due_date = ? WHERE id = ?");
        if ($stmt->execute([$description, $due_date, $id])) {
            $successMessage = "Todo updated successfully";
        } else {
            $errorMessage = "Failed to update todo";
        }
    }
}

// Always fetch the latest row to display
$stmt = $pdo->prepare("SELECT * FROM todos WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$todo = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$todo) {
    http_response_code(404);
    echo "Todo not found";
    exit;
}

require 'views/edit.html';
