# PHP Todo App — Enhanced

Improvements added on 2025-10-03:
- Edit Todo (link beside Mark Complete)
- Delete Todo (link beside Edit)
- **Due Today** section on the list page

## Requirements
- PHP 8+
- MySQL (database name: `todos`)
- Web server serving the project root

## Setup
1. Create the database:
   ```sql
   CREATE DATABASE IF NOT EXISTS todos;
   ```
2. Run the migration to ensure the `todos` table and columns exist:
   - Open your MySQL client and execute the SQL in `database/migrations/20251003_add_due_date_and_is_completed.sql`

3. Configure DB connection in `database/db.php` if needed (host, username, password). Default uses `root` with no password on `127.0.0.1`.

## Usage
- Go to `index.php` to see the list:
  - **Due Today** appears first.
  - Each todo shows **Mark Complete**, **Edit**, **Delete**.
- Use **Create** in the nav to add a new todo with a due date.
- Use **Edit** to update description or due date.
- Use **Delete** to remove a todo (asks for confirmation).

## File additions
- `edit.php` — edit form + update logic
- `delete.php` — delete logic
- `views/edit.html` — edit view
- `views/partials/todo_item.html` — shared renderer
- `database/migrations/20251003_add_due_date_and_is_completed.sql` — schema safety

## Notes
- If your server is configured to mount CSS from `/assets/pico.min.css`, no change needed.
- Code keeps your original helper functions (`db_insert`, `db_update`). Custom queries are used for fetch-by-id and delete for simplicity.
