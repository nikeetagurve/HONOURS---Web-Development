<?php
require 'database/db.php';

$pdo = db_connect();

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo "Missing id";
    exit;
}
$id = intval($_GET['id']);

// Simple delete
$stmt = $pdo->prepare("DELETE FROM todos WHERE id = ?");
$stmt->execute([$id]);

header("Location: index.php");
